-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: modelogymv5
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.18-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `modelogymv5`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `modelogymv5` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `modelogymv5`;

--
-- Table structure for table `auditoria`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `auditoria` (
  `idAuditoria` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(30) NOT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`idAuditoria`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--


--
-- Table structure for table `cargo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `cargo` (
  `idCargo` int(11) NOT NULL AUTO_INCREMENT,
  `nombreCargo` varchar(30) NOT NULL,
  `descripcionCargo` text DEFAULT NULL,
  `salario` float(9,2) NOT NULL,
  `idEmpleado` int(4) DEFAULT NULL,
  PRIMARY KEY (`idCargo`),
  KEY `cargo_empleado` (`idEmpleado`),
  KEY `indexCargo` (`idCargo`),
  CONSTRAINT `cargo_empleado` FOREIGN KEY (`idEmpleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cargo`
--

INSERT INTO `cargo` (`idCargo`, `nombreCargo`, `descripcionCargo`, `salario`, `idEmpleado`) VALUES (1,'ADMINISTRADOR','PERSONAL MANEJO CONFIANZA',1800000.00,2001),(2,'INSTRUCTOR','INSTRUCTOR PILATES',1000000.00,2002),(3,'CONTADOR','PROFESIONAL CONTADURIA PUBLICA',1500000.00,NULL);

--
-- Table structure for table `clave`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `clave` (
  `idClave` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(60) NOT NULL,
  `pwd` varchar(30) DEFAULT NULL,
  `idEmpleado` int(4) DEFAULT NULL,
  PRIMARY KEY (`idClave`),
  KEY `clave_empleado` (`idEmpleado`),
  KEY `indexClave` (`usuario`),
  CONSTRAINT `clave_empleado` FOREIGN KEY (`idEmpleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clave`
--

INSERT INTO `clave` (`idClave`, `usuario`, `pwd`, `idEmpleado`) VALUES (1,'juana@hotmail.com','pZyke2003',2001),(2,'sergio@gmail.com','Fall1234',2002);
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger Audita_modifica_tabla_clave 
after update on clave for each row
insert into auditoria(usuario,descripcion,fecha)
values (user(),
concat('Se modifico el  : ', old.usuario,' Valor antiguo : ',
(old.pwd), '  Nuevo valor', (new.pwd)),now()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_clave
	after update on clave for each row
	begin
		if (old.usuario<>new.usuario)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.usuario ,' Nuevo usuario : ',(new.usuario)), now());
		end if;
		if(old.pwd<>new.pwd)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.pwd ,' Nueva clave : ',(new.pwd)), now());
	  	end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `cliente`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `cliente` (
  `idCliente` int(15) NOT NULL,
  `idPersona` int(15) DEFAULT NULL,
  PRIMARY KEY (`idCliente`),
  KEY `cliente_persona` (`idPersona`),
  KEY `indexCliente` (`idCliente`),
  CONSTRAINT `cliente_persona` FOREIGN KEY (`idPersona`) REFERENCES `persona` (`idPersona`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`idCliente`, `idPersona`) VALUES (5001,1003828639),(5003,1003828800),(5004,1003856801),(5002,1085923987);

--
-- Table structure for table `empleado`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `empleado` (
  `idEmpleado` int(4) NOT NULL,
  `rol` varchar(20) NOT NULL,
  `descripcionRol` text DEFAULT NULL,
  `fechaContratacion` date DEFAULT '1900-12-01',
  PRIMARY KEY (`idEmpleado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleado`
--

INSERT INTO `empleado` (`idEmpleado`, `rol`, `descripcionRol`, `fechaContratacion`) VALUES (2001,'Admin','Administra los accesos de los usuarios, sin ser root','2018-10-03'),(2002,'BásicoNivel1','Consulta procesos los clientes','2019-12-06'),(2003,'BásicoNivel2','Consulta datos contables y financieros','1900-12-01'),(2004,'',NULL,'2018-06-23');
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_empleado
	after update on empleado for each row
	begin
		if (old.rol<>new.rol)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.rol ,' nombre : ',(new.rol)), now());
		end if;
		if(old.descripcionRol<>new.descripcionRol)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.descripcionRol ,' nombre : ',(new.descripcionRol)), now());
	  	end if;
		if(old.fechaContratacion<>new.fechaContratacion)
			then insert into auditoria(usuario,descripcion,fecha)
			values (user(),
			concat('se modifico : ',old.fechaContratacion ,' nombre : ',(new.fechaContratacion)), now());
		end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `factorrh`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `factorrh` (
  `idFactor` int(2) NOT NULL,
  `nombre` varchar(10) NOT NULL,
  PRIMARY KEY (`idFactor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factorrh`
--

INSERT INTO `factorrh` (`idFactor`, `nombre`) VALUES (1,'POSITIVO'),(2,'NEGATIVO');

--
-- Table structure for table `factura`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `factura` (
  `idFactura` int(4) NOT NULL,
  `fechaFactura` date NOT NULL,
  `idCliente` int(15) NOT NULL,
  PRIMARY KEY (`idFactura`),
  KEY `factura_cliente` (`idCliente`),
  KEY `indexFactura` (`idFactura`),
  CONSTRAINT `factura_cliente` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura`
--

INSERT INTO `factura` (`idFactura`, `fechaFactura`, `idCliente`) VALUES (3001,'2020-09-25',5001),(3002,'2020-08-03',5002);

--
-- Table structure for table `factura_producto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `factura_producto` (
  `idFactura` int(4) NOT NULL,
  `idProducto` int(4) NOT NULL,
  KEY `idFactura` (`idFactura`),
  KEY `idProducto` (`idProducto`),
  CONSTRAINT `factura_producto_ibfk_1` FOREIGN KEY (`idFactura`) REFERENCES `factura` (`idFactura`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `factura_producto_ibfk_2` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_producto`
--

INSERT INTO `factura_producto` (`idFactura`, `idProducto`) VALUES (3001,6001),(3002,6002);

--
-- Table structure for table `genero`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `genero` (
  `idGenero` int(2) NOT NULL,
  `nombre` varchar(5) NOT NULL,
  PRIMARY KEY (`idGenero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genero`
--

INSERT INTO `genero` (`idGenero`, `nombre`) VALUES (1,'M'),(2,'F'),(3,'OTRO');

--
-- Table structure for table `gruposanguineo`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gruposanguineo` (
  `idGrupo` int(2) NOT NULL,
  `nombre` varchar(2) NOT NULL,
  PRIMARY KEY (`idGrupo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gruposanguineo`
--

INSERT INTO `gruposanguineo` (`idGrupo`, `nombre`) VALUES (10,'O'),(11,'A'),(12,'B'),(13,'AB');

--
-- Table structure for table `gruposanguineo_factorrh`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `gruposanguineo_factorrh` (
  `idGrupo` int(2) NOT NULL,
  `idFactor` int(2) NOT NULL,
  KEY `idGrupo` (`idGrupo`),
  KEY `idFactor` (`idFactor`),
  CONSTRAINT `gruposanguineo_factorrh_ibfk_1` FOREIGN KEY (`idGrupo`) REFERENCES `gruposanguineo` (`idGrupo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `gruposanguineo_factorrh_ibfk_2` FOREIGN KEY (`idFactor`) REFERENCES `factorrh` (`idFactor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gruposanguineo_factorrh`
--

INSERT INTO `gruposanguineo_factorrh` (`idGrupo`, `idFactor`) VALUES (10,1),(11,2),(13,1);

--
-- Table structure for table `persona`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `persona` (
  `idPersona` int(15) NOT NULL,
  `primerNombre` varchar(20) NOT NULL,
  `segundoNombre` varchar(20) DEFAULT NULL,
  `primerApellido` varchar(20) NOT NULL,
  `segundoApellido` varchar(20) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `direccion` varchar(50) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `idTipoDocu` int(2) NOT NULL,
  `idGenero` int(2) NOT NULL,
  `idGrupo` int(2) DEFAULT NULL,
  `idEmpleado` int(4) DEFAULT NULL,
  PRIMARY KEY (`idPersona`),
  KEY `persona_tipoDocu` (`idTipoDocu`),
  KEY `persona_genero` (`idGenero`),
  KEY `persona_grupoSanguineo` (`idGrupo`),
  KEY `persona_empleado` (`idEmpleado`),
  KEY `indexPersona` (`idPersona`),
  CONSTRAINT `persona_empleado` FOREIGN KEY (`idEmpleado`) REFERENCES `empleado` (`idEmpleado`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `persona_genero` FOREIGN KEY (`idGenero`) REFERENCES `genero` (`idGenero`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `persona_grupoSanguineo` FOREIGN KEY (`idGrupo`) REFERENCES `gruposanguineo` (`idGrupo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `persona_tipoDocu` FOREIGN KEY (`idTipoDocu`) REFERENCES `tipodocumento` (`idTipoDocu`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `persona`
--

INSERT INTO `persona` (`idPersona`, `primerNombre`, `segundoNombre`, `primerApellido`, `segundoApellido`, `telefono`, `email`, `direccion`, `fechaNacimiento`, `idTipoDocu`, `idGenero`, `idGrupo`, `idEmpleado`) VALUES (1223432,'LIBARDO','ANTONIO','CASTAÑEDA','MOLINA','324657896','aunnotengo@com.co','centro','2000-02-19',1,1,13,NULL),(1002399872,'Ana','','La Forcade','','7846532','nosebiencuales@donde.com.co','carrera 125N # 17-100','1990-10-23',2,2,11,2002),(1003828639,'Paula','Analina','Cortez','Sepulveda','3456786','paulaanalina4562@gmail.com','Calle 45 # 5-87 Cerca algún lado','1980-10-23',4,1,NULL,NULL),(1003828800,'JULIAN',NULL,'CASTRO',NULL,'324657896','aunnotengo@com.co',NULL,'2018-12-31',3,1,NULL,NULL),(1003856801,'PETRONILA',NULL,'BERMUDES',NULL,'324897896','puedessereste@hotmail.co',NULL,'2014-11-19',1,2,NULL,NULL),(1085923987,'Belinda de Josefa','Maria','Ortiz','','3245621','lamasbonita521@yahoo.es','Av. 30 de agosto, cerca al banco Bogota','1980-12-16',2,2,NULL,NULL),(1786503863,'Roberto','De Jesus','Zapata','Montero','3285769','zariguellafeliz@nbc.com','Calle 63a #23-84','1984-05-15',1,1,10,2001);
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_persona
	after update on persona for each row
	begin
		if (old.telefono<>new.telefono)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.telefono ,' Nuevo número : ',(new.telefono)), now());
		end if;
		if(old.email<>new.email)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.email ,' Nuevo Email : ',(new.email)), now());
	  	end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `producto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `producto` (
  `idProducto` int(4) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `descripcion` text NOT NULL,
  `cantidad` int(11) NOT NULL,
  `valorUnitario` decimal(9,2) NOT NULL,
  `stockMinimo` int(11) NOT NULL,
  `stockMaximo` int(11) NOT NULL,
  `idTipoProducto` int(4) DEFAULT NULL,
  PRIMARY KEY (`idProducto`),
  KEY `producto_tipoProducto` (`idTipoProducto`),
  KEY `indexProducto` (`idProducto`,`nombre`),
  CONSTRAINT `producto_tipoProducto` FOREIGN KEY (`idTipoProducto`) REFERENCES `tipoproducto` (`idTipoProducto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chequeo_stockMaximo` CHECK (`stockMaximo` >= 100),
  CONSTRAINT `chequeo_stockMinimo` CHECK (`stockMinimo` <= 10)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

INSERT INTO `producto` (`idProducto`, `nombre`, `descripcion`, `cantidad`, `valorUnitario`, `stockMinimo`, `stockMaximo`, `idTipoProducto`) VALUES (6001,'CookEnergy','Lorem ipsum dolor sit amet consectetur adipisicing elit.',300,2000.00,4,101,4001),(6002,'Red Bull','Lorem ipsum dolor sit amet consectetur adipisicing elit.',205,5000.00,5,102,4001),(6003,'TNT','Lorem ipsum dolor sit amet consectetur adipisicing elit.',500,15000.00,6,103,4002),(6004,'Speed','Lorem ipsum dolor sit amet consectetur adipisicing elit.',500,2500.00,7,103,4003);
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger Audita_modifica_tabla_producto 
after update on producto for each row
insert into auditoria(usuario,descripcion,fecha)
values (user(),
concat('Se modifico el precio : ', old.descripcion,' valor antiguo : ',
(old.valorUnitario), ' Nuevo valor : ', (new.valorUnitario)),now()) */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_producto
	after update on producto for each row
	begin
		if (old.nombre<>new.nombre)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.nombre ,' Nuevo nombre : ',(new.nombre)), now());
		end if;
		if(old.descripcion<>new.descripcion)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.descripcion ,' Nueva descripcion : ',(new.descripcion)), now());
	  	end if;
	  	if(old.cantidad<>new.cantidad)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.cantidad ,' Nueva cantidad : ',(new.cantidad)), now());
	  	end if;
	  	if(old.valorUnitario<>new.valorUnitario)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.valorUnitario ,' Nueva precio : ',(new.valorUnitario)), now());
	  	end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `proveedor`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `proveedor` (
  `idProveedor` int(4) NOT NULL,
  `nombre` varchar(35) NOT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`idProveedor`),
  KEY `indexProveedor` (`idProveedor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

INSERT INTO `proveedor` (`idProveedor`, `nombre`, `descripcion`) VALUES (8001,'FIRTS NUTRITION','Lorem ipsum dolor sit amet consectetur adipisicing elit'),(8002,'GYMATIZE','Lorem ipsum dolor sit amet consectetur adipisicing elit'),(8003,'BE ONE','Lorem ipsum dolor sit amet consectetur adipisicing elit'),(8004,'SPEED',NULL);
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_proveedor
	after update on proveedor for each row
	begin
		if (old.nombre<>new.nombre)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.nombre ,' Nuevo nombre : ',(new.nombre)), now());
		end if;
		if(old.descripcion<>new.descripcion)
			then insert into auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.descripcion ,' Nueva descripcion : ',(new.descripcion)), now());
	  	end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `proveedor_producto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `proveedor_producto` (
  `idProveedor` int(4) NOT NULL,
  `idProducto` int(4) NOT NULL,
  KEY `idProducto` (`idProducto`),
  KEY `idProveedor` (`idProveedor`),
  CONSTRAINT `proveedor_producto_ibfk_1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `proveedor_producto_ibfk_2` FOREIGN KEY (`idProveedor`) REFERENCES `proveedor` (`idProveedor`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor_producto`
--

INSERT INTO `proveedor_producto` (`idProveedor`, `idProducto`) VALUES (8001,6001),(8002,6002),(8003,6003);

--
-- Table structure for table `tipodocumento`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tipodocumento` (
  `idTipoDocu` int(2) NOT NULL,
  `nombre` varchar(5) NOT NULL,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`idTipoDocu`),
  KEY `indexIdDocu` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipodocumento`
--

INSERT INTO `tipodocumento` (`idTipoDocu`, `nombre`, `descripcion`) VALUES (1,'CC','CEDULA DE CIUDADANIA'),(2,'TI','TARJETA DE IDENTIDAD'),(3,'RUT','REGISTRO UNICO TRIBUTARIO'),(4,'CE','CEDULA DE EXTRANGERIA');

--
-- Table structure for table `tipoproducto`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `tipoproducto` (
  `idTipoProducto` int(4) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY (`idTipoProducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipoproducto`
--

INSERT INTO `tipoproducto` (`idTipoProducto`, `nombre`) VALUES (4001,'BEBIDA ENERGISANTE'),(4002,'PROTEINA'),(4003,'DULCE ENERGISANTE');
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 trigger audita_actualizar_tipo_producto
	after update on tipoproducto for each row
	begin
		if (old.nombre<>new.nombre)
			then insert into  auditoria(usuario,descripcion,fecha)
			values(user(),
			concat('se modifico : ',old.nombre ,' Nuevo nombre : ',(new.nombre)), now());
		end if;
	end */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `vistacompletacliente`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vistacompletacliente` AS SELECT 
 1 AS `CODIGOCLIENTE`,
 1 AS `CEDULA`,
 1 AS `DESCRIPCION`,
 1 AS `P_NOMBRE`,
 1 AS `P_APELLIDO`,
 1 AS `DIRECCION`,
 1 AS `TELEFONO`,
 1 AS `EMAIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistadatoscliente`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vistadatoscliente` AS SELECT 
 1 AS `idcliente`,
 1 AS `idPersona`,
 1 AS `nombre`,
 1 AS `primerNombre`,
 1 AS `segundoNombre`,
 1 AS `primerApellido`,
 1 AS `segundoApellido`,
 1 AS `direccion`,
 1 AS `telefono`,
 1 AS `email`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistadatosclienteindividual`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vistadatosclienteindividual` AS SELECT 
 1 AS `CODIGOCLIENTE`,
 1 AS `CEDULA`,
 1 AS `DESCRIPCION`,
 1 AS `P_NOMBRE`,
 1 AS `P_APELLIDO`,
 1 AS `DIRECCION`,
 1 AS `TELEFONO`,
 1 AS `EMAIL`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaempleadocargo`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vistaempleadocargo` AS SELECT 
 1 AS `idEmpleado`,
 1 AS `idPersona`,
 1 AS `nombre`,
 1 AS `primerNombre`,
 1 AS `segundoNombre`,
 1 AS `primerApellido`,
 1 AS `telefono`,
 1 AS `fechaNacimiento`,
 1 AS `nombreCargo`,
 1 AS `salario`,
 1 AS `fechaContratacion`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistarolesempleado`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `vistarolesempleado` AS SELECT 
 1 AS `CEDULA`,
 1 AS `P_NOMBRE`,
 1 AS `S_NOMBRE`,
 1 AS `P_APELLIDO`,
 1 AS `S_APELLIDO`,
 1 AS `CARGO`,
 1 AS `rol`,
 1 AS `descripcionrol`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'modelogymv5'
--
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPdeleter_Datos_proveedor`(in del_nom varchar(35))
begin
	 delete from proveedor where nombre = del_nom;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPinsertar_Datos_cliente`(
	IN newcodigo_persona INT(15),
	IN newpnombre_persona VARCHAR(20),
	IN newpapellido_persona VARCHAR(20),
	IN newtelefono_persona VARCHAR(15),
	IN newemail_persona VARCHAR(60),
	IN newfecha DATE, 
	IN newtipodocu_tipodocu INT(2),
	IN newgenero_genero INT(2),
	IN newcodigo_cliente INT(4) 
	)
BEGIN
	START TRANSACTION;
	INSERT INTO persona (idPersona,primerNombre,primerApellido,telefono,email,fechaNacimiento,idTipoDocu,idGenero) 
    VALUES 
    (newcodigo_persona,newpnombre_persona,newpapellido_persona,newtelefono_persona,newemail_persona,newfecha,newtipodocu_tipodocu,newgenero_genero);
    INSERT INTO cliente (idCliente,idPersona) VALUES (newcodigo_cliente,newcodigo_persona);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPinsertar_Datos_persona`(
	IN newcodigo_persona INT,
	IN newpnombre_persona VARCHAR(20),
	IN newsnombre_persona VARCHAR(20),
	IN newpapellido_persona VARCHAR(20),
	IN newsapellido_persona VARCHAR(20),
	IN newtelefono_persona VARCHAR(15),
	IN newemail_persona VARCHAR(60),
	IN newdireccion_persona VARCHAR(50),
	IN newfechaNacimiento_persona DATE, 
	IN newtipodocu_tipodocu INT(2),
	IN newgenero_genero INT(2),
	IN newgrupo_grupo INT(4),
	IN newcodigo_empleado INT(4),
	IN newfechacontratacion_empleado DATE,
	IN newcodigo_cargo INT(11)
    )
BEGIN
	START TRANSACTION;
	INSERT INTO persona (idPersona,primerNombre,segundoNombre,primerApellido,segundoApellido,telefono,email,direccion,fechaNacimiento,idTipoDocu,
	idGenero,idGrupo) 
    VALUES 
    (newcodigo_persona,newpnombre_persona,newsnombre_persona,newpapellido_persona,newsapellido_persona,newtelefono_persona,newemail_persona,
    newdireccion_persona,newfechaNacimiento_persona,newtipodocu_tipodocu,newgenero_genero,newgrupo_grupo);
    INSERT INTO empleado (idEmpleado,fechaContratacion)VALUES (newcodigo_empleado,newfechacontratacion_empleado);
   	INSERT INTO cargo(idCargo) VALUES(newcodigo_cargo);
  END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPinsertar_Datos_proveedor`(
	IN codigo INT(4),IN nombre VARCHAR(35),IN descipcion TEXT)
BEGIN
	    
    INSERT INTO proveedor (idProveedor,nombre,descripcion) 
    VALUES (codigo,nombre,descripcion);
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPselect_Datos_producto`()
BEGIN
	    
    SELECT * FROM producto WHERE idProducto = 6001;
    END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPupdate_Datos_proveedor`(
IN new_codigo INT(4),
IN new_nombre VARCHAR(35),
IN old_nombre VARCHAR(35))
BEGIN

UPDATE proveedor SET idProveedor = new_codigo, nombre = new_nombre
WHERE idProveedor = new_codigo;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Current Database: `modelogymv5`
--

USE `modelogymv5`;

--
-- Final view structure for view `vistacompletacliente`
--

/*!50001 DROP VIEW IF EXISTS `vistacompletacliente`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacompletacliente` AS select `cliente`.`idCliente` AS `CODIGOCLIENTE`,`persona`.`idPersona` AS `CEDULA`,`tipodocumento`.`nombre` AS `DESCRIPCION`,`persona`.`primerNombre` AS `P_NOMBRE`,`persona`.`primerApellido` AS `P_APELLIDO`,`persona`.`direccion` AS `DIRECCION`,`persona`.`telefono` AS `TELEFONO`,`persona`.`email` AS `EMAIL` from ((`cliente` left join `persona` on(`cliente`.`idPersona` = `persona`.`idPersona`)) left join `tipodocumento` on(`persona`.`idTipoDocu` = `tipodocumento`.`idTipoDocu`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistadatoscliente`
--

/*!50001 DROP VIEW IF EXISTS `vistadatoscliente`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vistadatoscliente` AS select `cliente`.`idCliente` AS `idcliente`,`persona`.`idPersona` AS `idPersona`,`tipodocumento`.`nombre` AS `nombre`,`persona`.`primerNombre` AS `primerNombre`,`persona`.`segundoNombre` AS `segundoNombre`,`persona`.`primerApellido` AS `primerApellido`,`persona`.`segundoApellido` AS `segundoApellido`,`persona`.`direccion` AS `direccion`,`persona`.`telefono` AS `telefono`,`persona`.`email` AS `email` from ((`cliente` left join `persona` on(`persona`.`idPersona` = `cliente`.`idPersona`)) left join `tipodocumento` on(`tipodocumento`.`idTipoDocu` = `persona`.`idTipoDocu`)) order by 2 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistadatosclienteindividual`
--

/*!50001 DROP VIEW IF EXISTS `vistadatosclienteindividual`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vistadatosclienteindividual` AS select `cliente`.`idCliente` AS `CODIGOCLIENTE`,`persona`.`idPersona` AS `CEDULA`,`tipodocumento`.`nombre` AS `DESCRIPCION`,`persona`.`primerNombre` AS `P_NOMBRE`,`persona`.`primerApellido` AS `P_APELLIDO`,`persona`.`direccion` AS `DIRECCION`,`persona`.`telefono` AS `TELEFONO`,`persona`.`email` AS `EMAIL` from ((`cliente` left join `persona` on(`cliente`.`idPersona` = `persona`.`idPersona`)) left join `tipodocumento` on(`persona`.`idTipoDocu` = `tipodocumento`.`idTipoDocu`)) where `persona`.`idPersona` = 1085923987 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaempleadocargo`
--

/*!50001 DROP VIEW IF EXISTS `vistaempleadocargo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaempleadocargo` AS select `empleado`.`idEmpleado` AS `idEmpleado`,`persona`.`idPersona` AS `idPersona`,`tipodocumento`.`nombre` AS `nombre`,`persona`.`primerNombre` AS `primerNombre`,`persona`.`segundoNombre` AS `segundoNombre`,`persona`.`primerApellido` AS `primerApellido`,`persona`.`telefono` AS `telefono`,`persona`.`fechaNacimiento` AS `fechaNacimiento`,`cargo`.`nombreCargo` AS `nombreCargo`,`cargo`.`salario` AS `salario`,`empleado`.`fechaContratacion` AS `fechaContratacion` from ((`cargo` left join (`empleado` left join `persona` on(`persona`.`idEmpleado` = `empleado`.`idEmpleado`)) on(`empleado`.`idEmpleado` = `cargo`.`idEmpleado`)) join `tipodocumento` on(`tipodocumento`.`idTipoDocu` = `persona`.`idTipoDocu`)) order by 3 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistarolesempleado`
--

/*!50001 DROP VIEW IF EXISTS `vistarolesempleado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vistarolesempleado` AS select `persona`.`idPersona` AS `CEDULA`,`persona`.`primerNombre` AS `P_NOMBRE`,`persona`.`segundoApellido` AS `S_NOMBRE`,`persona`.`primerApellido` AS `P_APELLIDO`,`persona`.`segundoApellido` AS `S_APELLIDO`,`cargo`.`nombreCargo` AS `CARGO`,`empleado`.`rol` AS `rol`,`empleado`.`descripcionRol` AS `descripcionrol` from ((`persona` left join `empleado` on(`persona`.`idEmpleado` = `empleado`.`idEmpleado`)) join `cargo` on(`empleado`.`idEmpleado` = `cargo`.`idEmpleado`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-21  0:26:27
